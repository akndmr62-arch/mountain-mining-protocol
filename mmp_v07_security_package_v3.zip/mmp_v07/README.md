# Mountain Mining Protocol — V0.7

## Current architecture

```text
MountainToken (1B fixed)
        |
        v
MiningVault  <---- reads ---- MiningPass
                                   ^
                                   |
                             user-owned NFT
                                   |
MiningEngine ----------------------+
       start-only router
```

### Mining flow
1. User signs EIP-712 `StartMining`.
2. `MiningEngine.mine()` forwards the authorization to `MiningPass`.
3. `MiningPass` verifies the signature and moves the NFT into its own custody.
4. `MiningEngine` syncs the authoritative position into `MiningVault`.
5. User waits.
6. User calls `MiningVault.claim(tokenId)` directly.
7. Vault pays the stored miner only.
8. User calls `MiningPass.releaseMining(tokenId)` directly.
9. NFT returns to the stored miner.

The Engine deliberately cannot claim or release. This makes it a convenience router rather than a trusted custodian.

## Fixed parameters
- MMP total supply: 1,000,000,000
- Mining Pass supply: 100,000
- Mining duration cap: 20 years / 630,720,000 seconds
- Total weighted power: 486,000
- No mint after fixed supply
- No owner/admin/upgrade/pause/blacklist

## Verification status
Static review and adversarial test design are included. Real Foundry execution is pending because this environment has no `forge`/`solc` binary and cannot download them.

Do not deploy to mainnet until the real compile, test, fuzz, invariant, static-analysis and independent-audit gates pass.
