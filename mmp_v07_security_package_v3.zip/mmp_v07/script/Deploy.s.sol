// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Script} from "forge-std/Script.sol";
import {MountainToken} from "../src/MountainToken.sol";
import {MiningPass} from "../src/MiningPass.sol";
import {MiningVault} from "../src/MiningVault.sol";
import {MiningEngine} from "../src/MiningEngine.sol";

/// @notice Genesis deployment sequence.
/// IMPORTANT: the deployer is the immutable MiningPass minter. Therefore this script is designed
/// to mint the complete 100,000-pass genesis set in a controlled deployment transaction sequence,
/// then the minter becomes economically inert because the contract hard-caps total supply at 100k.
/// If a separate sale contract is required before genesis minting, use a CREATE2 deployment factory
/// and make its address the immutable minter; do not add an owner/setMinter function to MiningPass.
contract Deploy is Script {
    function run() external returns (MountainToken token, MiningPass pass, MiningVault vault, MiningEngine engine) {
        uint256 pk = vm.envUint("PRIVATE_KEY");
        address deployer = vm.addr(pk);

        vm.startBroadcast(pk);

        // Pass must know its immutable minter. Use the genesis deployer for the closed genesis phase.
        pass = new MiningPass(deployer);

        // Vault can now be deployed because Pass address is known.
        // Token is deployed to deployer first to avoid a token<->vault constructor cycle.
        // The script transfers the full fixed supply to Vault before protocol activation.
        token = new MountainToken(deployer);
        vault = new MiningVault(address(token), address(pass));
        engine = new MiningEngine(address(pass), address(vault));

        require(token.transfer(address(vault), token.MAX_SUPPLY()), "VAULT_FUNDING_FAILED");
        require(token.balanceOf(deployer) == 0, "GENESIS_BALANCE_REMAINS");

        vm.stopBroadcast();
    }
}
