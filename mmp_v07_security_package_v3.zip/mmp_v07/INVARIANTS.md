# Protocol invariants

1. `MountainToken.totalSupply() == 1_000_000_000e18` forever.
2. `MiningPass.totalMinted <= 100_000` forever.
3. Every class count is <= its hard cap.
4. A mining NFT is either owned by its miner or by MiningPass custody.
5. If `miningInfo(tokenId).active == true`, normal ERC721 transfer/approval cannot move it.
6. An active position's miner/start/power must equal Vault's snapshot.
7. Vault can only pay the stored miner.
8. `totalEmitted <= 1_000_000_000e18` forever.
9. A position can be claimed at most once.
10. A mining period can be released at most once.
11. Reward is monotonic with elapsed time until the 20-year cap.
12. Reward after 20 years equals reward at 20 years.
13. No protocol function can mint additional MMP.
