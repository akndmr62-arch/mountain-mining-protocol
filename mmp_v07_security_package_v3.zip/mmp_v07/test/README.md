# Test plan

The suite covers:
- invalid signatures
- replayed start signatures
- expired signatures
- NFT custody and transfer blocking
- direct attacker claim/release attempts
- 20-year reward calculation
- >20-year cap
- class supply cap
- accidental transfer-to-Pass lock prevention
- fuzzed elapsed-time emission ceiling
- total emitted invariant

Before mainnet, add:
1. ERC-1271 smart-wallet signature test
2. malformed signature lengths
3. boundary timestamps
4. every class reward
5. exact 1B theoretical aggregate emission simulation
6. malicious router/Engine tests
7. forced ETH/token transfers
8. Base fork test
9. gas snapshots
10. Slither + Echidna/Foundry invariant campaign
