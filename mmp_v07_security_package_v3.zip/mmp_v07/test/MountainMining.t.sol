// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {Test} from "forge-std/Test.sol";
import {MountainToken} from "../src/MountainToken.sol";
import {MiningPass} from "../src/MiningPass.sol";
import {MiningVault} from "../src/MiningVault.sol";
import {MiningEngine} from "../src/MiningEngine.sol";

contract MountainMiningTest is Test {
    MountainToken token;
    MiningPass pass;
    MiningVault vault;
    MiningEngine engine;

    uint256 userPk = 0xA11CE;
    address user;
    uint256 attackerPk = 0xB0B;
    address attacker;

    bytes32 constant START_TYPEHASH = keccak256("StartMining(address miner,uint256 tokenId,uint256 nonce,uint256 deadline)");

    function setUp() public {
        user = vm.addr(userPk);
        attacker = vm.addr(attackerPk);

        pass = new MiningPass(address(this));
        token = new MountainToken(address(this));
        vault = new MiningVault(address(token), address(pass));
        engine = new MiningEngine(address(pass), address(vault));
        require(token.transfer(address(vault), token.MAX_SUPPLY()));

        pass.mint(user, 1, pass.STONE());
    }

    function _domainSeparator(address verifyingContract, string memory name) internal view returns (bytes32) {
        return keccak256(abi.encode(
            keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
            keccak256(bytes(name)),
            keccak256(bytes("1")),
            block.chainid,
            verifyingContract
        ));
    }

    function _signStart(uint256 pk, address miner, uint256 tokenId, uint256 nonce, uint256 deadline)
        internal view returns (bytes memory)
    {
        bytes32 structHash = keccak256(abi.encode(START_TYPEHASH, miner, tokenId, nonce, deadline));
        bytes32 digest = keccak256(abi.encodePacked("\x19\x01", _domainSeparator(address(pass), "Mountain Mining Pass"), structHash));
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(pk, digest);
        return abi.encodePacked(r, s, v);
    }

    function _start(uint256 tokenId) internal {
        uint256 deadline = block.timestamp + 1 days;
        bytes memory sig = _signStart(userPk, user, tokenId, pass.miningNonces(user), deadline);
        vm.prank(user);
        engine.mine(tokenId, 0, deadline, sig);
    }

    function test_StartLocksNFTAndBlocksTransfers() public {
        _start(1);
        assertEq(pass.ownerOf(1), address(pass));
        (address miner,, uint8 power, bool active) = pass.miningInfo(1);
        assertEq(miner, user);
        assertEq(power, 1);
        assertTrue(active);

        vm.prank(user);
        vm.expectRevert();
        pass.transferFrom(user, attacker, 1);

        vm.prank(attacker);
        vm.expectRevert();
        pass.transferFrom(address(pass), attacker, 1);
    }

    function test_InvalidSignatureReplayAndExpiry() public {
        uint256 deadline = block.timestamp + 1 days;
        bytes memory sig = _signStart(userPk, user, 1, 0, deadline);
        vm.prank(user);
        engine.mine(1, 0, deadline, sig);

        vm.expectRevert();
        engine.mine(1, 0, deadline, sig);

        pass.mint(user, 2, pass.STONE());
        uint256 expired = block.timestamp;
        bytes memory expiredSig = _signStart(userPk, user, 2, pass.miningNonces(user), expired);
        vm.warp(expired + 1);
        vm.prank(user);
        vm.expectRevert();
        engine.mine(2, 1, expired, expiredSig);
    }

    function test_RewardMathTwentyYears() public {
        _start(1);
        vm.warp(block.timestamp + 630_720_000);

        uint256 beforeBal = token.balanceOf(user);
        vm.prank(user);
        vault.claim(1);
        uint256 reward = token.balanceOf(user) - beforeBal;
        assertEq(reward, 2_057_613_168_724_279_835_000); // 2,057.613... MMP
        assertEq(vault.totalEmitted(), reward);
    }

    function test_RewardCapsAtTwentyYears() public {
        _start(1);
        vm.warp(block.timestamp + 630_720_000 + 100 days);
        vm.prank(user);
        vault.claim(1);
        uint256 reward = token.balanceOf(user);
        assertEq(reward, 2_057_613_168_724_279_835_000);
    }

    function test_NonMinerCannotClaimOrRelease() public {
        _start(1);
        vm.warp(block.timestamp + 1 days);
        vm.prank(attacker);
        vm.expectRevert();
        vault.claim(1);

        vm.prank(attacker);
        vm.expectRevert();
        pass.releaseMining(1);
    }

    function test_ClaimThenDirectUserRelease() public {
        _start(1);
        vm.warp(block.timestamp + 1 days);
        vm.prank(user);
        vault.claim(1);
        assertEq(pass.ownerOf(1), address(pass));

        vm.prank(user);
        pass.releaseMining(1);
        assertEq(pass.ownerOf(1), user);
        (,,, bool active) = pass.miningInfo(1);
        assertFalse(active);
    }

    function test_AccidentalTransferToPassBlocked() public {
        vm.prank(user);
        vm.expectRevert();
        pass.transferFrom(user, address(pass), 1);
    }

    function test_DirectVaultClaimCannotBeFrontRunToAttacker() public {
        _start(1);
        vm.warp(block.timestamp + 1 days);
        uint256 attackerBefore = token.balanceOf(attacker);
        vm.prank(attacker);
        vm.expectRevert();
        vault.claim(1);
        assertEq(token.balanceOf(attacker), attackerBefore);
        assertTrue(vault.positions(1).active);
    }

    function test_DoubleClaimFails() public {
        _start(1);
        vm.warp(block.timestamp + 1 days);
        vm.prank(user);
        vault.claim(1);
        vm.prank(user);
        vm.expectRevert();
        vault.claim(1);
    }

    function test_ClaimDoesNotReleaseNFTUntilMinerReleases() public {
        _start(1);
        vm.warp(block.timestamp + 1 days);
        vm.prank(user);
        vault.claim(1);
        assertEq(pass.ownerOf(1), address(pass));
        vm.prank(user);
        pass.releaseMining(1);
        assertEq(pass.ownerOf(1), user);
    }

    function test_EngineCannotClaimOrRelease() public {
        _start(1);
        vm.warp(block.timestamp + 1 days);
        vm.prank(address(engine));
        vm.expectRevert();
        vault.claim(1);
        vm.prank(address(engine));
        vm.expectRevert();
        pass.releaseMining(1);
    }

    function test_ClassCaps() public {
        for (uint256 i = 2; i <= 40_000; i++) {
            pass.mint(user, i, pass.STONE());
        }
        vm.expectRevert();
        pass.mint(user, 40_002, pass.STONE());
    }

    function testFuzz_RewardNeverExceedsTwentyYearCap(uint256 dt) public {
        _start(1);
        dt = bound(dt, 0, 10_000_000_000);
        vm.warp(block.timestamp + dt);
        vm.prank(user);
        vault.claim(1);
        assertLe(vault.totalEmitted(), token.MAX_SUPPLY());
    }

    function invariant_TotalEmissionNeverExceedsCap() public view {
        assertLe(vault.totalEmitted(), token.MAX_SUPPLY());
    }
}
