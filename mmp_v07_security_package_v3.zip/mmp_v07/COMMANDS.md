# Local verification commands

```bash
forge install OpenZeppelin/openzeppelin-contracts --no-commit
forge install foundry-rs/forge-std --no-commit
forge fmt
forge build --sizes
forge test -vvv
forge test --match-test testFuzz_RewardNeverExceedsTwentyYearCap -vvv
forge test --match-test test_ClassCaps -vvv
```

Security tooling:

```bash
slither .
echidna-test .
```

Mainnet gate:

```text
forge build --sizes           PASS
forge test -vvv               PASS
fuzz campaign                 PASS
invariant campaign            PASS
slither                       PASS / reviewed
Base fork integration         PASS
independent audit             PASS
constructor args verified     PASS
source verification           PASS
```
