# Deployment and circular-dependency resolution

V0.6 had a real constructor dependency problem:

`Pass -> Engine -> Vault -> Pass` and `Token -> Vault -> Token`.

V0.7 breaks the first cycle by making Pass the NFT custodian and Engine stateless. The token cycle is broken by deploying the fixed-supply token to the genesis deployer, then transferring exactly 1B MMP to the Vault before activation.

## Recommended genesis sequence
1. Deploy `MiningPass` with a controlled immutable genesis minter.
2. Deploy `MountainToken` with the genesis deployer as initial holder.
3. Deploy `MiningVault(token, pass)`.
4. Deploy `MiningEngine(pass, vault)`.
5. Transfer exactly `MountainToken.MAX_SUPPLY()` to Vault.
6. Verify deployer token balance is zero.
7. Mint the exact 100,000 NFT genesis allocation through the immutable minter. After total supply reaches 100,000, the minter has no further economic ability to mint.
8. Publish verified source code and constructor arguments.

## Important production-sale point
The final Mystery Box sale must NOT let the buyer submit `classId`. That would destroy the mystery-box property. Use a verifiable randomness mechanism (e.g. Chainlink VRF or another audited Base-compatible provider) and map the random output to the remaining class inventory.

The `MiningPass` class caps are the final on-chain backstop: even a faulty allocation algorithm cannot mint beyond the seven class maxima.

## Why not add `setMinter`?
Because that would recreate the exact admin backdoor this architecture is trying to remove. If a dedicated sale contract is needed, solve the constructor cycle with CREATE2 address prediction: precompute the Pass address from the known minter address and Pass creation code, deploy the minter with that predicted Pass address, then CREATE2-deploy Pass with the minter address.
