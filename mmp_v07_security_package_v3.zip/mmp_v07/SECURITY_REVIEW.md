# MMP V0.7 Security Review — Static Pass

## Status
Static review completed in this environment. Foundry/solc binaries are not installed and outbound DNS is unavailable, so an actual EVM compile/test run could not be executed here.

## Critical correction from prior V0.7 draft
`MiningEngine.claim()` was unsafe as an implementation idea because a call from Engine reaches Vault with `msg.sender == Engine`, while Vault's direct claim requires the stored miner. The corrected architecture removes Engine claim/release entirely.

Engine is now **start-only**. Reward claim and NFT release are direct user calls:

1. `MiningEngine.mine(...)`
2. `MiningVault.claim(tokenId)` by the stored miner
3. `MiningPass.releaseMining(tokenId)` by the stored miner

This avoids circular immutable authorization and removes unnecessary Engine trust.

## Threat model checks
- Unauthorized mint: blocked by immutable minter.
- Global supply > 100,000 NFTs: blocked.
- Per-class supply overflow: blocked.
- Invalid mining signature: blocked by EIP-712 + SignatureChecker.
- Signature replay: nonce consumed.
- Cross-chain / cross-contract replay: EIP-712 domain.
- Mining transfer theft: blocked by custody and active-mining checks.
- Accidental transfer into Pass custody: blocked.
- Attacker claim: blocked because Vault checks stored miner == msg.sender.
- Attacker release: blocked because Pass checks stored miner == msg.sender.
- Fake Vault position: blocked because Pass must already own the NFT and report active mining state.
- Vault reward manipulation: reward is calculated by Vault from its stored position plus live Pass cross-check.
- Recipient substitution: impossible; reward recipient is `p.miner`.
- Double claim: position is deleted before token transfer; second claim sees inactive position.
- Reentrancy: Vault claim is `nonReentrant` and follows checks-effects-interactions.
- Emission > 1B MMP: cap checked before emission.
- Reward beyond 20 years: elapsed is capped.
- Upgrade/admin drain: no owner/admin/upgrade path.

## Remaining pre-mainnet gates
- `forge build`
- `forge test -vvv`
- high-volume fuzzing
- invariant testing with randomized action sequences
- Slither
- Echidna
- Base fork testing
- ERC-1271 test suite
- malicious ERC20 return/reentrancy test suite
- gas report
- independent smart-contract audit
- testnet deployment and multi-day soak test
