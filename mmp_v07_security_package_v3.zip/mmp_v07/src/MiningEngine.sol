// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {IMiningPass, IMiningVault} from "./interfaces.sol";

/// @notice Stateless convenience router. It never owns NFT/MMP and has no admin path.
contract MiningEngine {
    IMiningPass public immutable miningPass;
    IMiningVault public immutable vault;

    error InvalidAddress();
    error VaultStartFailed();

    constructor(address pass_, address vault_) {
        if (pass_ == address(0) || vault_ == address(0)) revert InvalidAddress();
        miningPass = IMiningPass(pass_);
        vault = IMiningVault(vault_);
    }

    function mine(
        uint256 tokenId,
        uint256 nonce,
        uint256 deadline,
        bytes calldata signature
    ) external {
        miningPass.startMining(msg.sender, tokenId, nonce, deadline, signature);
        vault.startMining(tokenId);
    }

}
