// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

interface IMintablePass {
    function mint(address to, uint256 tokenId, uint8 classId) external;
}

/// @notice Minimal immutable minter shell. It has no owner/setter.
/// The final public sale MUST supply verifiable randomness; this shell accepts a class selected by
/// an external randomness coordinator only after its result is validated off-chain/on-chain.
contract MiningMinter {
    IMintablePass public immutable pass;
    address payable public immutable treasury;
    uint256 public immutable firstTokenId;
    uint256 public immutable maxTokenId;
    uint256 public nextTokenId;

    error NotPass();
    error SoldOut();
    error ZeroAddress();

    constructor(address predictedPass, address payable treasury_, uint256 firstId, uint256 lastId) {
        if (predictedPass == address(0) || treasury_ == address(0) || firstId == 0 || lastId < firstId) revert ZeroAddress();
        pass = IMintablePass(predictedPass);
        treasury = treasury_;
        firstTokenId = firstId;
        maxTokenId = lastId;
        nextTokenId = firstId;
    }

    /// @dev Called by the final sale/randomness module after a class has been deterministically selected.
    function mintFromAuthorizedFlow(address to, uint8 classId) external returns (uint256 tokenId) {
        // This function is intentionally NOT exposed as a production public-sale entry point in this shell.
        // The final sale should own the payment/randomness flow and then invoke this function through a
        // tightly scoped authorization mechanism. Leaving it open would let anyone mint for free.
        if (msg.sender != address(pass)) revert NotPass();
        if (nextTokenId > maxTokenId) revert SoldOut();
        tokenId = nextTokenId++;
        pass.mint(to, tokenId, classId);
    }
}
