// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

interface IMountainToken {
    function transfer(address to, uint256 amount) external returns (bool);
}

interface IMiningPass {
    function ownerOf(uint256 tokenId) external view returns (address);
    function miningInfo(uint256 tokenId) external view returns (address miner, uint64 startTime, uint8 power, bool active);
    function startMining(address miner, uint256 tokenId, uint256 nonce, uint256 deadline, bytes calldata signature) external;
    function releaseMining(uint256 tokenId) external;
}

interface IMiningVault {
    function startMining(uint256 tokenId) external;
}
