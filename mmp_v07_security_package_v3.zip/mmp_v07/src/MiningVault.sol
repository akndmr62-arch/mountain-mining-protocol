// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IMountainToken, IMiningPass} from "./interfaces.sol";

/// @notice Sole MMP emission source. No owner, withdrawals, upgrades or arbitrary recipients.
contract MiningVault is ReentrancyGuard {
    uint256 public constant MAX_SUPPLY = 1_000_000_000 ether;
    uint256 public constant MAX_MINING_SECONDS = 630_720_000;
    uint256 public constant TOTAL_POWER = 486_000;

    struct Position {
        address miner;
        uint64 startTime;
        uint8 power;
        bool active;
    }

    IMountainToken public immutable mmp;
    IMiningPass public immutable miningPass;
    mapping(uint256 => Position) public positions;
    uint256 public totalEmitted;

    error ZeroAddress();
    error InvalidPosition();
    error PositionMismatch();
    error NotMiner();
    error NoReward();
    error EmissionCapExceeded();
    error TokenTransferFailed();

    constructor(address mmp_, address pass_) {
        if (mmp_ == address(0) || pass_ == address(0)) revert ZeroAddress();
        mmp = IMountainToken(mmp_);
        miningPass = IMiningPass(pass_);
    }

    /// @notice Anyone may sync an already-authorized live mining position into the Vault.
    /// It moves no funds and cannot manufacture a position because MiningPass is authoritative.
    function startMining(uint256 tokenId) external {
        if (miningPass.ownerOf(tokenId) != address(miningPass)) revert InvalidPosition();
        (address pMiner, uint64 startTime, uint8 power, bool active) = miningPass.miningInfo(tokenId);
        if (!active || pMiner == address(0) || startTime > block.timestamp || !_validPower(power)) {
            revert InvalidPosition();
        }
        if (positions[tokenId].active) revert InvalidPosition();
        positions[tokenId] = Position(pMiner, startTime, power, true);
    }

    /// @notice Direct user claim path. The caller must be the stored miner.
    function claim(uint256 tokenId) external nonReentrant returns (uint256 reward) {
        return _claim(tokenId, msg.sender);
    }

    function _claim(uint256 tokenId, address recipient) internal returns (uint256 reward) {
        Position memory p = positions[tokenId];
        if (!p.active || p.miner != recipient) revert NotMiner();

        (address pMiner, uint64 startTime, uint8 power, bool active) = miningPass.miningInfo(tokenId);
        if (!active || pMiner != p.miner || startTime != p.startTime || power != p.power) revert PositionMismatch();
        if (miningPass.ownerOf(tokenId) != address(miningPass)) revert InvalidPosition();

        uint256 elapsed = block.timestamp - uint256(p.startTime);
        if (elapsed > MAX_MINING_SECONDS) elapsed = MAX_MINING_SECONDS;
        reward = elapsed * uint256(p.power) * 1_000_000_000 ether
            / (MAX_MINING_SECONDS * TOTAL_POWER);
        if (reward == 0) revert NoReward();
        if (totalEmitted > MAX_SUPPLY - reward) revert EmissionCapExceeded();

        delete positions[tokenId];
        totalEmitted += reward;
        if (!mmp.transfer(p.miner, reward)) revert TokenTransferFailed();
    }

    function remainingEmission() external view returns (uint256) {
        return MAX_SUPPLY - totalEmitted;
    }

    function _validPower(uint8 p) internal pure returns (bool) {
        return p == 1 || p == 2 || p == 4 || p == 8 || p == 16 || p == 32 || p == 64;
    }
}
