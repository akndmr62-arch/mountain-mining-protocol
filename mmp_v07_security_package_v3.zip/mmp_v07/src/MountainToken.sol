// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @notice Fixed-supply MMP token. Supply is minted to the deployer, then deployment script
/// atomically transfers all 1B MMP into the immutable Vault before the protocol is opened.
contract MountainToken is ERC20 {
    uint256 public constant MAX_SUPPLY = 1_000_000_000 ether;

    constructor(address initialHolder) ERC20("Mountain", "MMP") {
        require(initialHolder != address(0), "ZERO_HOLDER");
        _mint(initialHolder, MAX_SUPPLY);
    }
}
