// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {SignatureChecker} from "@openzeppelin/contracts/utils/cryptography/SignatureChecker.sol";

/// @notice 100,000 capped mining NFTs. While mining, the NFT is custodied by this contract.
/// The contract has no owner/admin/upgrade mechanism.
contract MiningPass is ERC721, EIP712 {
    uint256 public constant MAX_SUPPLY = 100_000;
    uint256 public constant MAX_MINING_SECONDS = 630_720_000; // 20 years at 365 days/year

    uint8 public constant STONE = 1;
    uint8 public constant OBSIDIAN = 2;
    uint8 public constant IRON = 3;
    uint8 public constant STEEL = 4;
    uint8 public constant TITANIUM = 5;
    uint8 public constant DIAMOND = 6;
    uint8 public constant MITHRIL = 7;

    uint256 public constant STONE_MAX = 40_000;
    uint256 public constant OBSIDIAN_MAX = 25_000;
    uint256 public constant IRON_MAX = 15_000;
    uint256 public constant STEEL_MAX = 10_000;
    uint256 public constant TITANIUM_MAX = 6_000;
    uint256 public constant DIAMOND_MAX = 3_000;
    uint256 public constant MITHRIL_MAX = 1_000;

    bytes32 private constant START_TYPEHASH = keccak256(
        "StartMining(address miner,uint256 tokenId,uint256 nonce,uint256 deadline)"
    );

    struct MiningLock {
        address miner;
        uint64 startTime;
        uint8 power;
        bool active;
    }

    address public immutable minter;
    uint256 public totalMinted;
    mapping(uint8 => uint256) public classMinted;
    mapping(uint256 => uint8) public classOf;
    mapping(uint256 => MiningLock) private _mining;
    mapping(address => uint256) public miningNonces;
    bool private _custodyTransfer;

    error UnauthorizedMinter();
    error InvalidTokenId();
    error InvalidClass();
    error TotalSupplyExceeded();
    error ClassSupplyExceeded();
    error NotOwner();
    error InvalidNonce();
    error SignatureExpired();
    error InvalidSignature();
    error AlreadyMining();
    error NotMining();
    error WrongMiner();
    error InvalidStartTime();
    error CustodyTransferForbidden();
    error MiningTransferForbidden();

    constructor(address minter_) ERC721("Mountain Mining Pass", "MMPASS") EIP712("Mountain Mining Pass", "1") {
        if (minter_ == address(0)) revert UnauthorizedMinter();
        minter = minter_;
    }

    function mint(address to, uint256 tokenId, uint8 classId) external {
        if (msg.sender != minter) revert UnauthorizedMinter();
        if (to == address(0) || tokenId == 0 || tokenId > MAX_SUPPLY) revert InvalidTokenId();
        if (classId < STONE || classId > MITHRIL) revert InvalidClass();
        if (totalMinted >= MAX_SUPPLY) revert TotalSupplyExceeded();
        if (classMinted[classId] >= _classMaximum(classId)) revert ClassSupplyExceeded();

        unchecked {
            totalMinted++;
            classMinted[classId]++;
        }
        classOf[tokenId] = classId;
        _mint(to, tokenId);
    }

    function miningInfo(uint256 tokenId) external view returns (address miner, uint64 startTime, uint8 power, bool active) {
        MiningLock memory l = _mining[tokenId];
        return (l.miner, l.startTime, l.power, l.active);
    }

    function miningNonce(address miner) external view returns (uint256) {
        return miningNonces[miner];
    }

    function startMining(
        address miner,
        uint256 tokenId,
        uint256 nonce,
        uint256 deadline,
        bytes calldata signature
    ) external {
        if (block.timestamp > deadline) revert SignatureExpired();
        if (nonce != miningNonces[miner]) revert InvalidNonce();
        if (_ownerOf(tokenId) != miner) revert NotOwner();
        if (_mining[tokenId].active) revert AlreadyMining();

        bytes32 digest = _hashTypedDataV4(keccak256(abi.encode(
            START_TYPEHASH, miner, tokenId, nonce, deadline
        )));
        if (!SignatureChecker.isValidSignatureNow(miner, digest, signature)) revert InvalidSignature();

        unchecked { miningNonces[miner] = nonce + 1; }
        _mining[tokenId] = MiningLock({
            miner: miner,
            startTime: uint64(block.timestamp),
            power: _powerOf(classOf[tokenId]),
            active: true
        });

        _custodyTransfer = true;
        _update(address(this), tokenId, address(0));
        _custodyTransfer = false;
    }

    /// @notice Ends the mining period and returns the NFT to its stored miner.
    /// Only the miner can execute this function; Engine is deliberately not trusted.
    function releaseMining(uint256 tokenId) external {
        MiningLock memory l = _mining[tokenId];
        if (!l.active) revert NotMining();
        if (l.miner != msg.sender) revert WrongMiner();

        delete _mining[tokenId];
        _custodyTransfer = true;
        _update(msg.sender, tokenId, address(0));
        _custodyTransfer = false;
    }

    function _update(address to, uint256 tokenId, address auth) internal override returns (address) {
        address from = _ownerOf(tokenId);

        if (!_custodyTransfer) {
            if (from == address(this) || to == address(this)) revert CustodyTransferForbidden();
            if (_mining[tokenId].active) revert MiningTransferForbidden();
        }
        return super._update(to, tokenId, auth);
    }

    function approve(address to, uint256 tokenId) public override {
        if (_mining[tokenId].active) revert MiningTransferForbidden();
        super.approve(to, tokenId);
    }

    function _classMaximum(uint8 classId) internal pure returns (uint256) {
        if (classId == STONE) return STONE_MAX;
        if (classId == OBSIDIAN) return OBSIDIAN_MAX;
        if (classId == IRON) return IRON_MAX;
        if (classId == STEEL) return STEEL_MAX;
        if (classId == TITANIUM) return TITANIUM_MAX;
        if (classId == DIAMOND) return DIAMOND_MAX;
        if (classId == MITHRIL) return MITHRIL_MAX;
        revert InvalidClass();
    }

    function _powerOf(uint8 classId) internal pure returns (uint8) {
        if (classId == STONE) return 1;
        if (classId == OBSIDIAN) return 2;
        if (classId == IRON) return 4;
        if (classId == STEEL) return 8;
        if (classId == TITANIUM) return 16;
        if (classId == DIAMOND) return 32;
        if (classId == MITHRIL) return 64;
        revert InvalidClass();
    }

    function powerOf(uint256 tokenId) external view returns (uint8) {
        return _powerOf(classOf[tokenId]);
    }
}
